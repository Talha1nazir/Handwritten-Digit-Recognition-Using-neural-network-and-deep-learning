# Replaced by d3 directory

This directory contains python code which generated png figures which
were later replaced by d3 in the live version of the site.  They've
been preserved here on the off chance that they may be of use at some
point in the future.
